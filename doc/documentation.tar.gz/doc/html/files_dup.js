var files_dup =
[
    [ "CHANGELOG", "a00056.html", null ],
    [ "COPYING", "a00062.html", null ],
    [ "COPYING.LESSER", "a00065.html", null ],
    [ "CAEN_FELib.h", "a00041.html", "a00041" ],
    [ "INSTALL", "a00059.html", null ],
    [ "PYCHANGELOG", "a00083.html", null ],
    [ "__init__.py", "a00068.html", "a00068" ],
    [ "_utils.py", "a00071.html", "a00071" ],
    [ "device.py", "a00077.html", "a00077" ],
    [ "error.py", "a00074.html", [
      [ "ErrorCode", "a00122.html", null ],
      [ "Error", "a00126.html", "a00126" ]
    ] ],
    [ "lib.py", "a00080.html", [
      [ "_Lib", "a00130.html", "a00130" ]
    ] ]
];