var searchData=
[
  ['utility_20macros_0',['Utility macros',['../a00089.html',1,'']]]
];
