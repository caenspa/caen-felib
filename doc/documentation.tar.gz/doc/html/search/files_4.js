var searchData=
[
  ['install_0',['INSTALL',['../a00059.html',1,'']]],
  ['install_2emd_1',['INSTALL.md',['../a00053.html',1,'']]]
];
