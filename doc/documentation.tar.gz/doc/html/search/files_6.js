var searchData=
[
  ['introduction_2emd_0',['INTRODUCTION.md',['../a00280.html',1,'']]],
  ['pychangelog_1',['PYCHANGELOG',['../a00083.html',1,'']]]
];
