var namespaces_dup =
[
    [ "caen_felib", "a00094.html", "a00094" ]
];